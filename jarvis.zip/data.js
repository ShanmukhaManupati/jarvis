const obj = {
    hello: "hi"
}