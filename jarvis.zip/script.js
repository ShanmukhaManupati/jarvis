let user_input = document.getElementById("input");

user_input.addEventListener("keyup", (event) => {
    if(event.key === "Enter") {
        submit()
    }
})

function user() {
    let parentElement = document.createElement("div");
    parentElement.className = "user";

    let userImg = document.createElement("img");
    userImg.src = "user.png";

    let newElement = document.createElement("span");
    newElement.className = "user-res";

    parentElement.appendChild(newElement);
    let response_area = document.querySelector(".response-area");
    response_area.appendChild(parentElement);
    parentElement.appendChild(userImg);

    newElement.textContent = user_input.value;
    user_input.value = "";
}

function jarvisCode(content) {
    let parentElement = document.createElement("div");
    parentElement.className = "jarvis";

    let userImg = document.createElement("img");
    userImg.src = "jarvis.png";

    let newElement = document.createElement("span");
    newElement.className = "jarvis-res";

    parentElement.appendChild(userImg);
    parentElement.appendChild(newElement);
    let response_area = document.querySelector(".response-area");
    response_area.appendChild(parentElement);

    newElement.textContent = content;
}

function autoScroll() {
    let response_area = document.querySelector(".response-area");
    response_area.scrollTop = response_area.scrollHeight;
}


function submit() {
    if(user_input.value != ""){

    const processedInput = user_input.value.toLowerCase();
    user()

        if(processedInput == "hi") {
            jarvisCode("Hello")
        } 
        else if(processedInput == "date") {
            let date = new Date().toDateString();
            jarvisCode(date);
        }
        else if(processedInput == "time") {
            let time = new Date().toLocaleTimeString();
            jarvisCode(time);
        }
        else if(processedInput == "clear") {
            document.querySelector(".response-area").innerHTML = "";
        }
        else {
            jarvisCode("Sorry it's not in my data list!");
        }
        }
        else {
            return true;
        }
    autoScroll();
}